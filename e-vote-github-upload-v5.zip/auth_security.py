"""Small dependency-free password hashing and signed session helpers."""
import base64
import hashlib
import hmac
import json
import os
import secrets
import time

ITERATIONS = 390_000

def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
    return f"pbkdf2_sha256${ITERATIONS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"

def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, rounds, salt_b64, digest_b64 = encoded.split("$")
        if scheme != "pbkdf2_sha256":
            return False
        salt = base64.urlsafe_b64decode(salt_b64)
        expected = base64.urlsafe_b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(rounds))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False

def _secret() -> bytes:
    secret = os.getenv("SESSION_SECRET")
    if not secret or len(secret) < 32:
        raise RuntimeError("Set SESSION_SECRET to a random value of at least 32 characters")
    return secret.encode("utf-8")

def issue_token(user_id: str, expires_in: int = 8 * 60 * 60) -> str:
    header = base64.urlsafe_b64encode(b'{"alg":"HS256","typ":"JWT"}').rstrip(b"=").decode()
    payload = base64.urlsafe_b64encode(json.dumps({"sub": user_id, "exp": int(time.time()) + expires_in}, separators=(",", ":")).encode()).rstrip(b"=").decode()
    message = f"{header}.{payload}"
    signature = base64.urlsafe_b64encode(hmac.new(_secret(), message.encode(), hashlib.sha256).digest()).rstrip(b"=").decode()
    return f"{message}.{signature}"

def read_token(token: str) -> str:
    try:
        header, payload, signature = token.split(".")
        message = f"{header}.{payload}"
        expected = base64.urlsafe_b64encode(hmac.new(_secret(), message.encode(), hashlib.sha256).digest()).rstrip(b"=").decode()
        if not hmac.compare_digest(expected, signature):
            raise ValueError("Invalid signature")
        data = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
        if int(data["exp"]) <= int(time.time()):
            raise ValueError("Expired session")
        return str(data["sub"])
    except Exception as exc:
        raise ValueError("Invalid or expired session") from exc
