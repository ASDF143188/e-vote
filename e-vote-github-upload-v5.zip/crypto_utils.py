"""Authenticated AES-256-GCM encryption for sensitive database text values."""
import base64
import os
import secrets
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from sqlalchemy.types import Text, TypeDecorator

PREFIX = "aes256gcm:"

def _key() -> bytes:
    value = os.getenv("DATABASE_ENCRYPTION_KEY", "")
    try:
        key = bytes.fromhex(value)
    except ValueError as exc:
        raise RuntimeError("DATABASE_ENCRYPTION_KEY must be 64 hex characters (32 bytes)") from exc
    if len(key) != 32:
        raise RuntimeError("DATABASE_ENCRYPTION_KEY must be 64 hex characters (32 bytes)")
    return key

def encrypt_text(value):
    if value is None:
        return None
    if not isinstance(value, str):
        value = str(value)
    nonce = secrets.token_bytes(12)
    ciphertext = AESGCM(_key()).encrypt(nonce, value.encode("utf-8"), None)
    return PREFIX + base64.urlsafe_b64encode(nonce + ciphertext).decode("ascii")

def decrypt_text(value):
    if value is None or not value.startswith(PREFIX):
        # Preserve and allow reading older plaintext rows; next write re-encrypts them.
        return value
    try:
        payload = base64.urlsafe_b64decode(value[len(PREFIX):].encode("ascii"))
        return AESGCM(_key()).decrypt(payload[:12], payload[12:], None).decode("utf-8")
    except Exception as exc:
        raise RuntimeError("Encrypted database field could not be decrypted; verify DATABASE_ENCRYPTION_KEY") from exc

class EncryptedText(TypeDecorator):
    impl = Text
    cache_ok = True
    def process_bind_param(self, value, dialect):
        return encrypt_text(value)
    def process_result_value(self, value, dialect):
        return decrypt_text(value)
