import cv2
import numpy as np
import base64
import json
import os
from crypto_utils import encrypt_text, decrypt_text

class FaceRecognizer:
    """
    Face-recognition adapter that fails closed when the provider is unavailable.
    """
    
    @staticmethod
    def encrypt_encoding(encoding):
        return encrypt_text(json.dumps(encoding, separators=(",", ":")))

    @staticmethod
    def decrypt_encoding(stored):
        if not stored or not stored.startswith("aes256gcm:"):
            raise RuntimeError("This face template is not AES-256 encrypted. Re-enroll it before verification.")
        try:
            return json.loads(decrypt_text(stored))
        except (TypeError, ValueError) as exc:
            raise RuntimeError("Face template is invalid. Re-enroll the voter.") from exc

    @staticmethod
    def encode_face(image_path=None, image_array=None):
        """
        Encode a face using the configured face_recognition provider.
        """
        try:
            # Try to use real face_recognition
            import face_recognition
            
            if image_path:
                image = face_recognition.load_image_file(image_path)
            elif image_array is not None:
                image = image_array
            else:
                return None
            
            face_locations = face_recognition.face_locations(image)
            if len(face_locations) == 0:
                return None
            
            face_encodings = face_recognition.face_encodings(image, face_locations)
            if len(face_encodings) > 0:
                return face_encodings[0].tolist()
            return None
            
        except ImportError as exc:
            raise RuntimeError("Face recognition provider is not installed; enrollment is disabled.") from exc
    
    @staticmethod
    def verify_face(known_encoding, image_array):
        """
        Verify a face using the configured face_recognition provider.
        """
        try:
            import face_recognition
            import numpy as np
            
            known_encoding_np = np.array(known_encoding)
            face_locations = face_recognition.face_locations(image_array)
            
            if len(face_locations) == 0:
                return False, 0.0
            
            face_encodings = face_recognition.face_encodings(image_array, face_locations)
            if len(face_encodings) == 0:
                return False, 0.0
            
            matches = face_recognition.compare_faces([known_encoding_np], face_encodings[0], tolerance=0.6)
            face_distance = face_recognition.face_distance([known_encoding_np], face_encodings[0])
            confidence = (1.0 - face_distance[0]) * 100
            
            return matches[0], confidence
            
        except ImportError as exc:
            raise RuntimeError("Face recognition provider is not installed; verification is disabled.") from exc
    
    @staticmethod
    def decode_base64_image(base64_string):
        """Convert base64 image to numpy array"""
        try:
            if ',' in base64_string:
                base64_string = base64_string.split(',')[1]
            
            image_data = base64.b64decode(base64_string, validate=True)
            if not image_data or len(image_data) > 4 * 1024 * 1024:
                return None
            nparr = np.frombuffer(image_data, np.uint8)
            img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
            if img is None:
                return None
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            return img_rgb
        except Exception as e:
            print(f"Error decoding image: {e}")
            return None
    
    @staticmethod
    def detect_face_in_image(image_array):
        """Detect if face exists in image"""
        try:
            import face_recognition
            face_locations = face_recognition.face_locations(image_array)
            return len(face_locations) > 0
        except ImportError as exc:
            raise RuntimeError("Face recognition provider is not installed; detection is disabled.") from exc


