from database import SessionLocal, create_tables
import models
import uuid

def seed_database():
    # Create tables first
    create_tables()
    
    db = SessionLocal()
    
    try:
        # No local test accounts are created. Administrator bootstrap must be
        # implemented securely before this API is used.

        # Create synthetic example parties and candidates once. These are
        # data-only demo records; no admin or voter passwords are seeded.
        demo_parties = [
            ("Progress Alliance", "✳", "#087cff", "Practical ideas for a stronger community.", "Jordan Lee"),
            ("Community First", "◈", "#18c7a3", "Local voices and shared opportunity.", "Sam Rivera"),
            ("Future Forward", "✦", "#a27cf5", "Responsible innovation for everyone.", "Taylor Morgan"),
        ]
        for name, symbol, color, manifesto, candidate_name in demo_parties:
            party = db.query(models.Party).filter(models.Party.name.ilike(name)).first()
            if not party:
                party = models.Party(id=str(uuid.uuid4()), name=name, symbol=symbol,
                                     color=color, manifesto=manifesto)
                db.add(party)
                db.flush()
            candidate_exists = db.query(models.Candidate).filter(
                models.Candidate.name.ilike(candidate_name),
                models.Candidate.position.ilike("President"),
                models.Candidate.party_id == party.id
            ).first()
            if not candidate_exists:
                db.add(models.Candidate(id=str(uuid.uuid4()), name=candidate_name,
                                        position="President", party_id=party.id))
        
        # Create Election
        if not db.query(models.Election).first():
            election = models.Election(
                id=str(uuid.uuid4()),
                title="Digital Election 2026",
                status="ACTIVE"
            )
            db.add(election)
            print("✅ Election created")
        
        db.commit()
        print("\n🎉 Database seeded successfully!")
        
    except Exception as e:
        db.rollback()
        print(f"❌ Error seeding database: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()

