from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import func
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from auth_security import hash_password, verify_password, issue_token, read_token
import uuid, hashlib, hmac, os, json
from datetime import date, datetime, timedelta
from database import engine, get_db, create_tables
from seed import seed_database
import models, schemas
from face_utils import FaceRecognizer
import cloudinary, cloudinary.uploader

# Create tables
create_tables()
seed_database()

# Cloudinary setup (optional)
if os.getenv("CLOUDINARY_CLOUD_NAME"):
    cloudinary.config(
        cloud_name=os.getenv("CLOUDINARY_CLOUD_NAME"),
        api_key=os.getenv("CLOUDINARY_API_KEY"),
        api_secret=os.getenv("CLOUDINARY_API_SECRET")
    )

app = FastAPI(title="e-vote Educational Election Platform")
bearer = HTTPBearer(auto_error=False)

def current_user(credentials: HTTPAuthorizationCredentials = Depends(bearer), db: Session = Depends(get_db)):
    if not credentials:
        raise HTTPException(401, "Sign in required", headers={"WWW-Authenticate": "Bearer"})
    try:
        user_id = read_token(credentials.credentials)
    except (ValueError, RuntimeError):
        raise HTTPException(401, "Session invalid or expired", headers={"WWW-Authenticate": "Bearer"})
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(401, "Account not found")
    return user

def admin_user(user=Depends(current_user)):
    if user.role not in {"ADMIN", "SUPER_ADMIN"} or user.status != "VERIFIED":
        raise HTTPException(403, "Administrator access required")
    return user

def voter_user(user=Depends(current_user)):
    if user.role != "VOTER" or user.status != "VERIFIED":
        raise HTTPException(403, "Approved voter access required")
    return user

def normalized_username(value: str) -> str:
    return value.strip().casefold()

def normalized_phone(value: str) -> str:
    return "".join(ch for ch in value if ch.isdigit())

def ensure_unique_username(db: Session, username: str):
    if db.query(models.User).filter(func.lower(models.User.username) == username.strip().lower()).first():
        raise HTTPException(409, "That username is already in use. Choose a different username.")

def ensure_unique_voter_phone(db: Session, phone: str):
    phone_key = normalized_phone(phone)
    if phone_key and any(normalized_phone(user.phone or "") == phone_key for user in db.query(models.User).filter(models.User.role == "VOTER").all()):
        raise HTTPException(409, "That phone number is already registered to a voter.")

def unique_voters(users):
    # Keep the most established row in the visible directory if legacy data
    # contains case-variant usernames; writes are rejected as duplicates below.
    unique = {}
    for user in users:
        key = normalized_username(user.username)
        current = unique.get(key)
        rank = (user.status == "VERIFIED", user.created_at or datetime.min, user.id)
        current_rank = (current.status == "VERIFIED", current.created_at or datetime.min, current.id) if current else None
        if current is None or rank > current_rank:
            unique[key] = user
    return list(unique.values())

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[origin.strip() for origin in os.getenv("CORS_ORIGINS", "").split(",") if origin.strip()],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==================== AUTHENTICATION ====================

@app.post("/api/bootstrap-admin")
def bootstrap_admin(payload: schemas.BootstrapAdmin, db: Session = Depends(get_db)):
    expected = os.getenv("BOOTSTRAP_ADMIN_TOKEN", "")
    if len(expected) < 32 or not hmac.compare_digest(expected, payload.token):
        raise HTTPException(403, "Invalid bootstrap token")
    if db.query(models.User).filter(models.User.role.in_(["ADMIN", "SUPER_ADMIN"])).count():
        raise HTTPException(409, "Administrator setup is already complete")
    ensure_unique_username(db, payload.username)
    admin = models.User(id=str(uuid.uuid4()), username=payload.username, phone=payload.phone,
                        password=hash_password(payload.password), role="SUPER_ADMIN", status="VERIFIED")
    db.add(admin)
    try:
        db.commit()
    except Exception as exc:
        db.rollback()
        raise HTTPException(409, "Administrator username is already in use") from exc
    return {"success": True, "message": "Initial administrator created. Remove BOOTSTRAP_ADMIN_TOKEN from service settings now."}

@app.post("/api/register")
def register(user: schemas.UserRegister, db: Session = Depends(get_db)):
    voter_count = db.query(models.User).filter(models.User.role == "VOTER").count()
    if voter_count >= int(os.getenv("MAX_VOTERS", "50")):
        raise HTTPException(409, "Voter registration is full (maximum 50 accounts).")
    ensure_unique_username(db, user.username)
    ensure_unique_voter_phone(db, user.phone)
    
    db_user = models.User(
        id=str(uuid.uuid4()),
        username=user.username.strip(),
        phone=user.phone,
        password=hash_password(user.password),
        status="PENDING",
        role="VOTER"
    )
    db.add(db_user)
    db.commit()
    return {"success": True, "message": "Registered. Awaiting admin approval."}

@app.post("/api/login")
def login(req: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(func.lower(models.User.username) == req.username.strip().lower()).first()
    if not user:
        raise HTTPException(401, "Invalid credentials")
    if not verify_password(req.password, user.password):
        # Migrate an existing local plaintext password only after a correct login.
        if hmac.compare_digest(str(user.password), req.password):
            user.password = hash_password(req.password)
            db.commit()
        else:
            raise HTTPException(401, "Invalid credentials")
    try:
        token = issue_token(user.id)
    except RuntimeError as exc:
        raise HTTPException(503, str(exc)) from exc
    return {
        "success": True,
        "token": token,
        "user": {
            "id": user.id,
            "role": user.role,
            "username": user.username,
            "status": user.status,
            "face_enrolled": user.face_enrolled
        }
    }

# ==================== DOCUMENT UPLOAD ====================

@app.post("/api/upload-doc")
async def upload_doc(user_id: str, file: UploadFile = File(...), db: Session = Depends(get_db), current=Depends(current_user)):
    if current.id != user_id and current.role not in {"ADMIN", "SUPER_ADMIN"}:
        raise HTTPException(403, "You may only upload your own document")
    if not os.getenv("CLOUDINARY_CLOUD_NAME"):
        raise HTTPException(503, "Document storage is not configured")
    try:
        result = cloudinary.uploader.upload(file.file, folder="e-vote-ids", resource_type="auto")
    except Exception as exc:
        raise HTTPException(502, "Document upload failed") from exc
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    user.document_url = result["secure_url"]
    db.commit()
    return {"success": True, "url": user.document_url}

# ==================== ADMIN DASHBOARD ====================

@app.get("/api/health")
def health():
    return {"ok": True, "mode": "test-prototype", "max_voters": int(os.getenv("MAX_VOTERS", "50"))}

@app.get("/api/admin/stats")
def admin_stats(db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    return {
        "total_votes": db.query(models.Vote).count(),
        "pending": len(unique_voters(db.query(models.User).filter(models.User.status == "PENDING", models.User.role == "VOTER").all())),
        "approved": len(unique_voters(db.query(models.User).filter(models.User.status == "VERIFIED", models.User.role == "VOTER").all())),
        "parties": db.query(models.Party).count()
    }

@app.get("/api/admin/pending")
def get_pending(db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    users = unique_voters(db.query(models.User).filter(
        models.User.status == "PENDING",
        models.User.role == "VOTER"
    ).all())
    return [{"id": u.id, "username": u.username, "phone": u.phone} for u in users]

@app.post("/api/admin/approve/{user_id}")
def approve_user(user_id: str, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    user.status = "VERIFIED"
    db.commit()
    return {"success": True}

@app.get("/api/admin/approved-users")
def get_approved_users(db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    users = unique_voters(db.query(models.User).filter(
        models.User.status == "VERIFIED",
        models.User.role == "VOTER"
    ).all())
    return [{"id": u.id, "username": u.username, "phone": u.phone,
             "face_enrolled": u.face_enrolled} for u in users]

# ==================== FACE RECOGNITION ====================

@app.post("/api/admin/enroll-face/{user_id}")
async def enroll_face(user_id: str, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    
    raise HTTPException(400, "Submit a face image to the upload-face-image endpoint; enrollment cannot be marked complete without a real match template.")

@app.post("/api/admin/upload-face-image/{user_id}")
async def upload_face_image(
    user_id: str,
    payload: schemas.FaceImageRequest,
    db: Session = Depends(get_db), current=Depends(admin_user)
):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    if user.role != "VOTER" or user.status != "VERIFIED":
        raise HTTPException(403, "Only an approved voter may be enrolled")
    if not payload.consent:
        raise HTTPException(400, "Explicit voter consent is required before biometric enrollment")
    if len(payload.face_image) > 6 * 1024 * 1024:
        raise HTTPException(413, "Image exceeds the 4 MB limit")
    
    try:
        # Decode base64 image
        image_array = FaceRecognizer.decode_base64_image(payload.face_image)
        
        if image_array is None:
            raise HTTPException(400, "Invalid image data")
        
        # Encode face
        face_encoding = FaceRecognizer.encode_face(image_array=image_array)
        
        if face_encoding is None:
            raise HTTPException(400, "No face detected. Please ensure face is clearly visible.")
        
        # Store face encoding as JSON string
        user.face_encoding = FaceRecognizer.encrypt_encoding(face_encoding)
        user.face_enrolled = True
        user.face_verified_at = None
        
        db.commit()
        return {"success": True, "message": "Face enrolled successfully!"}
        
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    except Exception as e:
        raise HTTPException(400, "Unable to process this image.") from e

@app.post("/api/voter/verify-face")
async def verify_face(
    user_id: str,
    payload: schemas.FaceImageRequest,
    db: Session = Depends(get_db), current=Depends(voter_user)
):
    user = current
    if user.id != user_id:
        raise HTTPException(403, "You may only verify your own face")
    if user.role != "VOTER" or user.status != "VERIFIED":
        raise HTTPException(403, "Only an approved voter can verify their face")
    if not user.face_enrolled or not user.face_encoding:
        raise HTTPException(400, "Face not enrolled. Contact an election administrator.")
    if len(payload.face_image) > 6 * 1024 * 1024:
        raise HTTPException(413, "Image exceeds the 4 MB limit")
    
    try:
        image_array = FaceRecognizer.decode_base64_image(payload.face_image)
        if image_array is None:
            raise HTTPException(400, "Invalid image data")
        
        stored_encoding = FaceRecognizer.decrypt_encoding(user.face_encoding)
        is_match, confidence = FaceRecognizer.verify_face(stored_encoding, image_array)
        
        if is_match and confidence >= 70:
            user.face_verified_at = __import__("datetime").datetime.utcnow()
            db.commit()
            return {
                "success": True,
                "message": f"Face verified! Confidence: {confidence:.1f}%",
                "confidence": confidence
            }
        else:
            raise HTTPException(
                401,
                f"Verification failed. Confidence: {confidence:.1f}%. Try again."
            )
    except RuntimeError as e:
        raise HTTPException(503, str(e))
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, "Unable to verify this image.") from e

# ==================== ADMIN MANAGEMENT ====================

@app.get("/api/admin/admins")
def get_admins(db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    admins = db.query(models.User).filter(models.User.role == "ADMIN").all()
    return [{"id": a.id, "username": a.username, "phone": a.phone} for a in admins]

@app.post("/api/admin/create-admin")
def create_admin(admin: schemas.AdminCreate, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    if admin_actor.role != "SUPER_ADMIN":
        raise HTTPException(403, "Only a super administrator can create admins")
    ensure_unique_username(db, admin.username)
    
    db_admin = models.User(
        id=str(uuid.uuid4()),
        username=admin.username,
        phone=admin.phone,
        password=hash_password(admin.password),
        role="ADMIN",
        status="VERIFIED"
    )
    db.add(db_admin)
    db.commit()
    return {"success": True}

@app.post("/api/admin/delete-admin/{admin_id}")
def delete_admin(admin_id: str, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    if admin_actor.role != "SUPER_ADMIN":
        raise HTTPException(403, "Only a super administrator can remove admins")
    admin = db.query(models.User).filter(
        models.User.id == admin_id,
        models.User.role == "ADMIN"
    ).first()
    if not admin:
        raise HTTPException(404, "Admin not found")
    db.delete(admin)
    db.commit()
    return {"success": True}

# ==================== PARTY & CANDIDATES ====================

@app.post("/api/admin/parties")
def create_party(party: schemas.PartyCreate, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    if db.query(models.Party).filter(func.lower(models.Party.name) == party.name.strip().lower()).first():
        raise HTTPException(409, "A party with that name already exists.")
    db_party = models.Party(
        id=str(uuid.uuid4()),
        **{**party.dict(), "name": party.name.strip()}
    )
    db.add(db_party)
    db.commit()
    return {"success": True}

@app.get("/api/admin/parties")
def get_parties(db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    parties = db.query(models.Party).all()
    return [
        {
            "id": p.id,
            "name": p.name,
            "symbol": p.symbol,
            "color": p.color,
            "manifesto": p.manifesto,
            "candidates": [{"id": c.id, "name": c.name, "position": c.position} for c in p.candidates]
        }
        for p in parties
    ]

@app.post("/api/admin/candidates")
def add_candidate(cand: schemas.CandidateCreate, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    duplicate = db.query(models.Candidate).filter(
        models.Candidate.party_id == cand.party_id,
        func.lower(models.Candidate.name) == cand.name.strip().lower(),
        func.lower(models.Candidate.position) == cand.position.strip().lower()
    ).first()
    if duplicate:
        raise HTTPException(409, "This candidate is already listed for that party and position.")
    db_cand = models.Candidate(
        id=str(uuid.uuid4()),
        **{**cand.dict(), "name": cand.name.strip(), "position": cand.position.strip()}
    )
    db.add(db_cand)
    db.commit()
    return {"success": True}

@app.delete("/api/admin/candidates/{candidate_id}")
def delete_candidate(candidate_id: str, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    candidate = db.query(models.Candidate).filter(models.Candidate.id == candidate_id).first()
    if not candidate:
        raise HTTPException(404, "Candidate not found")
    if db.query(models.Vote).filter(models.Vote.candidate_id == candidate_id).first():
        raise HTTPException(409, "Cannot remove a candidate with recorded votes")
    db.delete(candidate)
    db.commit()
    return {"success": True}

# ==================== ELECTION MANAGEMENT ====================

@app.post("/api/admin/elections")
def create_election(elec: schemas.ElectionCreate, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    db_elec = models.Election(
        id=str(uuid.uuid4()),
        title=elec.title,
        status="ACTIVE"
    )
    db.add(db_elec)
    db.commit()
    return {"success": True, "id": db_elec.id}

@app.put("/api/admin/elections/{election_id}/voters")
def assign_election_voters(election_id: str, payload: schemas.ElectionVotersUpdate, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    election = db.query(models.Election).filter(models.Election.id == election_id).first()
    if not election:
        raise HTTPException(404, "Election not found")
    if len(set(payload.user_ids)) != len(payload.user_ids):
        raise HTTPException(400, "Select each voter only once")
    users = db.query(models.User).filter(models.User.id.in_(payload.user_ids), models.User.role == "VOTER", models.User.status == "VERIFIED").all()
    if len(users) != len(payload.user_ids):
        raise HTTPException(400, "Every selected user must be an approved voter")
    selected = {u.id for u in users}
    current_rows = db.query(models.ElectionVoter).filter(models.ElectionVoter.election_id == election_id).all()
    for row in current_rows:
        if row.user_id not in selected:
            db.delete(row)
    current = {row.user_id for row in current_rows if row.user_id in selected}
    for user in users:
        if user.id not in current:
            db.add(models.ElectionVoter(id=str(uuid.uuid4()), election_id=election_id, user_id=user.id))
    db.commit()
    return {"success": True, "assigned": len(selected)}

@app.get("/api/admin/elections/{election_id}/voters")
def get_election_voters(election_id: str, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    return [{"id": row.user.id, "username": row.user.username, "phone": row.user.phone}
            for row in db.query(models.ElectionVoter).filter(models.ElectionVoter.election_id == election_id).all()]

@app.get("/api/admin/elections")
def get_elections(db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    elecs = db.query(models.Election).all()
    return [
        {"id": e.id, "title": e.title, "status": e.status, "votes": len(e.votes)}
        for e in elecs
    ]

@app.get("/api/admin/analytics")
def admin_analytics(election_id: str | None = None, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    today = date.today()
    first_day = today - timedelta(days=6)
    days = [(first_day + timedelta(days=i)).isoformat() for i in range(7)]
    vote_query = db.query(models.Vote).filter(models.Vote.timestamp >= datetime.combine(first_day, datetime.min.time()))
    if election_id:
        vote_query = vote_query.filter(models.Vote.election_id == election_id)
    by_day = {day: 0 for day in days}
    for vote in vote_query.all():
        key = (vote.timestamp.date() if vote.timestamp else today).isoformat()
        if key in by_day:
            by_day[key] += 1
    candidates = db.query(models.Candidate).all()
    counts = {}
    for candidate in candidates:
        key = (candidate.name.strip().casefold(), (candidate.position or "").strip().casefold(), candidate.party_id)
        row = counts.setdefault(key, {"name": candidate.name, "party": candidate.party.name,
                                     "color": candidate.party.color, "votes": 0})
        count_query = db.query(models.Vote).filter(models.Vote.candidate_id == candidate.id)
        if election_id:
            count_query = count_query.filter(models.Vote.election_id == election_id)
        row["votes"] += count_query.count()
    assigned = db.query(models.ElectionVoter).filter(models.ElectionVoter.election_id == election_id).count() if election_id else 0
    return {"votes_by_day": [{"date": day, "votes": by_day[day]} for day in days],
            "assigned_voters": assigned, "results": list(counts.values())}

@app.post("/api/admin/release/{election_id}")
def release_results(election_id: str, db: Session = Depends(get_db), admin_actor=Depends(admin_user)):
    elec = db.query(models.Election).filter(models.Election.id == election_id).first()
    if not elec:
        raise HTTPException(404, "Election not found")
    elec.status = "RELEASED"
    db.commit()
    return {"success": True}

# ==================== VOTING ====================

@app.get("/api/voter/elections")
def voter_elections(db: Session = Depends(get_db), voter=Depends(voter_user)):
    rows = db.query(models.Election).join(models.ElectionVoter, models.ElectionVoter.election_id == models.Election.id).filter(
        models.ElectionVoter.user_id == voter.id, models.Election.status == "ACTIVE").all()
    return [{"id": e.id, "title": e.title, "status": e.status, "votes": len(e.votes)} for e in rows]

@app.get("/api/voter/candidates/{election_id}")
def get_candidates(election_id: str, db: Session = Depends(get_db), voter=Depends(voter_user)):
    eligible = db.query(models.ElectionVoter).filter_by(election_id=election_id, user_id=voter.id).first()
    if not eligible:
        raise HTTPException(403, "You are not assigned to this election")
    cands = db.query(models.Candidate).all()
    return [{"id": c.id, "name": c.name, "party": c.party.name, "color": c.party.color,
             "party_id": c.party_id, "position": c.position} for c in cands]

@app.post("/api/voter/vote")
def cast_vote(vote: schemas.VoteRequest, db: Session = Depends(get_db), voter=Depends(voter_user)):
    if voter.id != vote.user_id:
        raise HTTPException(403, "You may only cast your own vote")
    election = db.query(models.Election).filter(models.Election.id == vote.election_id, models.Election.status == "ACTIVE").first()
    if not election:
        raise HTTPException(409, "This election is not accepting votes")
    assigned = db.query(models.ElectionVoter).filter(models.ElectionVoter.user_id == voter.id, models.ElectionVoter.election_id == election.id).first()
    if not assigned:
        raise HTTPException(403, "You are not assigned to this election")
    candidate = db.query(models.Candidate).filter(models.Candidate.id == vote.candidate_id).first()
    if not candidate:
        raise HTTPException(404, "Candidate not found")
    if not voter.face_enrolled or not voter.face_verified_at:
        raise HTTPException(403, "Complete face verification before voting")
    from datetime import datetime, timedelta
    if voter.face_verified_at < datetime.utcnow() - timedelta(minutes=10):
        raise HTTPException(403, "Face verification expired; verify again before voting")
    if db.query(models.Vote).filter(models.Vote.user_id == vote.user_id, models.Vote.election_id == vote.election_id).first():
        raise HTTPException(409, "Already voted in this election")
    
    # Generate receipt hash
    raw = f"{vote.user_id}-{vote.candidate_id}-{os.urandom(16).hex()}"
    block_hash = hashlib.sha256(raw.encode()).hexdigest()
    
    db_vote = models.Vote(
        id=str(uuid.uuid4()),
        user_id=vote.user_id,
        candidate_id=vote.candidate_id,
        election_id=vote.election_id,
        block_hash=block_hash
    )
    db.add(db_vote)
    voter.face_verified_at = None
    db.commit()
    return {"success": True, "receipt": block_hash}

# ==================== RESULTS ====================

@app.get("/api/results/{election_id}")
def get_results(election_id: str, db: Session = Depends(get_db)):
    election = db.query(models.Election).filter(models.Election.id == election_id).first()
    if not election:
        raise HTTPException(404, "Election not found")
    if election.status != "RELEASED":
        raise HTTPException(403, "Results have not been released")
    cands = db.query(models.Candidate).all()
    grouped = {}
    for c in cands:
        key = (c.name.strip().casefold(), (c.position or "").strip().casefold(), c.party_id)
        row = grouped.setdefault(key, {"name": c.name, "party": c.party.name, "color": c.party.color, "votes": 0})
        row["votes"] += db.query(models.Vote).filter(
            models.Vote.candidate_id == c.id,
            models.Vote.election_id == election_id
        ).count()
    return list(grouped.values())

# ==================== SERVE FRONTEND ====================

app.mount("/", StaticFiles(directory="static", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)



