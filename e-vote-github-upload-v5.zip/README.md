# e-vote test prototype

Responsive FastAPI and browser UI for learning and workflow checks. This is **not suitable for a real or binding election**. Face matching has no liveness/spoof protection; use synthetic test identities and consenting participants only.

## Features

- Dark navy and cyan responsive interface based on the supplied screenshots, with mobile navigation, logout, dashboard charts, and live vote analytics.
- Startup seeds one demo election, three sample parties, and one distinct sample candidate per party. It does not seed users or passwords.
- Login names are case-insensitive. New voter/admin usernames are unique regardless of letter case; voter phone numbers are normalized to prevent duplicate registrations. Duplicate candidates with the same name, position, and party are rejected.
- Dashboard charts use database vote data rather than placeholder totals. Duplicate candidate tallies are combined in results.
- Admins can approve voters, create elections, assign approved voters per election, and add/remove candidates in Manage Parties. A candidate with a recorded vote cannot be deleted.
- Passwords use salted PBKDF2-HMAC-SHA256 hashes. Phone, email, document URL, and face templates are encrypted with AES-256-GCM. Render Postgres encrypts storage at rest.
- Face enrollment requires consent, uses `face_recognition`, and fails closed if the provider or encryption key is unavailable.

## Local setup

1. Use Python 3.11 and install `requirements.txt`.
2. Set `SESSION_SECRET` (32+ characters), `BOOTSTRAP_ADMIN_TOKEN` (32+ random characters), and `DATABASE_ENCRYPTION_KEY` (64 hex characters / 32 bytes).
3. Start with `uvicorn main:app --reload`; startup creates the sample data. Open `http://localhost:8000`.
4. Create the first administrator by POSTing to `/api/bootstrap-admin` with `token`, `username`, `phone`, and a 12+ character `password`. No original/default account credentials exist. After success, remove `BOOTSTRAP_ADMIN_TOKEN`.
5. Register a voter in the site, then sign in as admin and approve the registration.

Generate local test secrets with `python -c "import secrets; print(secrets.token_urlsafe(48)); print(secrets.token_hex(32))"`. Never commit secret values. Back up the encryption key securely; without it, encrypted fields cannot be read.

## Render test deployment

The Blueprint uses `render.yaml` and `e-vote-github-upload-v5.zip` at the GitHub repository root. The bundle extracts the app into `build/`. Set `BOOTSTRAP_ADMIN_TOKEN` and `DATABASE_ENCRYPTION_KEY` as secret environment values. The free Render database is temporary; use synthetic test data only. The service has no liveness checks and must not be used for real elections.

## Security limits

This prototype is not independently audited, does not use a formal secret-ballot protocol, and must not be used for official elections.
