# e-vote — secure digital elections

A professional, responsive interface for the e-vote project, built from the code bundle in `projectfile.txt` and styled around the supplied dashboard references.

## Run locally

From the `outputs/e-vote` directory:

1. Install the dependencies: `pip install -r requirements.txt`
2. Create the local demo database: `python seed.py`
3. Start the app: `uvicorn main:app --reload`
4. Open `http://localhost:8000`

The dashboard opens in preview mode when the API is unavailable and uses sample values clearly labeled as preview data. With the API available, the interface loads voter, party, election, and result data from the existing routes. The visual design is a prototype and does not imply that the underlying voting system has security or ballot secrecy guarantees.

## Project contents

- `static/index.html` — landing page and workspace shell
- `static/styles.css` — responsive visual system and dashboard styles
- `static/app.js` — navigation, API integration, forms, and preview state
- Python modules — source files extracted from the supplied project bundle

## Code review notes

The supplied server includes several prototype-only security and integrity limitations. Passwords are stored and compared as plain text; most administration routes do not authenticate an admin; voting does not check election status or voter approval; duplicate-vote prevention is global per user instead of per election; and the face-recognition fallback can report a successful match without real recognition. The AES-256 and robust encryption claims in the pasted notes are not implemented in the supplied code. This is a learning prototype and is not ready to run a real election without a security redesign and independent review.

The supplied `schemas.py` section duplicated the seed script instead of defining the request schemas imported by `main.py`. A matching Pydantic schema module has been added so the provided backend routes can import their request models.





## Local testing credentials

The seeded demo accounts are:

- Admin: `admin` / `admin123`
- Super admin: `superadmin` / `super123`
- Voter: `voter1` / `voter123`

These accounts work in the browser-only preview and are also created by `python seed.py` for FastAPI testing. Preview submissions are browser-local only. Do not use these credentials for a live deployment.

The dashboard includes a sample weekly turnout line graph and a pie chart based on the displayed vote totals. API responses and seed creation avoid repeated voter, party, and candidate entries in the interface.

## Deploy a public preview on Render

This project is configured as a **static demo preview**. It serves the responsive website and browser-only sample accounts. Preview actions are stored in the visitor's browser and are not shared with other users. The Python API is intentionally not exposed by this deployment because its current prototype authentication and voting routes are not safe for a public election.

1. Put the `outputs/e-vote` folder in a GitHub, GitLab, or Bitbucket repository. Keep `render.yaml` at the repository root (or set the Render Blueprint path to `outputs/e-vote/render.yaml` if the project remains in a larger repository).
2. In Render, choose **New → Blueprint**, connect the repository, and select the branch containing this project.
3. Review the `e-vote-preview` static site, then apply the Blueprint. Render builds it from `static/` and assigns an `onrender.com` URL.
4. Open that URL and sign in with the demo credentials listed above. These are public demo credentials; never reuse them for a real election.

Render deploys from a connected Git repository, so this folder must be pushed to a Git provider before Render can publish it. To use persistent accounts, voter records, or real API actions, the backend needs a security redesign and a persistent database before deployment.
