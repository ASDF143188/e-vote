from fastapi import FastAPI, Depends, HTTPException, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import uuid, hashlib, os, json
from database import engine, get_db, create_tables
import models, schemas
from face_utils import FaceRecognizer
import cloudinary, cloudinary.uploader

# Create tables
create_tables()

# Cloudinary setup (optional)
if os.getenv("CLOUDINARY_CLOUD_NAME"):
    cloudinary.config(
        cloud_name=os.getenv("CLOUDINARY_CLOUD_NAME"),
        api_key=os.getenv("CLOUDINARY_API_KEY"),
        api_secret=os.getenv("CLOUDINARY_API_SECRET")
    )

app = FastAPI(title="e-vote Secure Platform")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==================== AUTHENTICATION ====================

@app.post("/api/register")
def register(user: schemas.UserRegister, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.username == user.username).first():
        raise HTTPException(400, "Username already exists")
    
    db_user = models.User(
        id=str(uuid.uuid4()),
        username=user.username,
        phone=user.phone,
        password=user.password,
        status="PENDING",
        role="VOTER"
    )
    db.add(db_user)
    db.commit()
    return {"success": True, "message": "Registered. Awaiting admin approval."}

@app.post("/api/login")
def login(req: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(
        models.User.username == req.username,
        models.User.password == req.password
    ).first()
    
    if not user:
        raise HTTPException(401, "Invalid credentials")
    
    return {
        "success": True,
        "user": {
            "id": user.id,
            "role": user.role,
            "username": user.username,
            "status": user.status,
            "face_enrolled": user.face_enrolled
        }
    }

# ==================== DOCUMENT UPLOAD ====================

@app.post("/api/upload-doc")
async def upload_doc(user_id: str, file: UploadFile = File(...), db: Session = Depends(get_db)):
    # Mock URL for local development
    doc_url = f"https://mock-cloud.com/ids/{file.filename}"
    
    # Upload to Cloudinary if configured
    if os.getenv("CLOUDINARY_CLOUD_NAME"):
        try:
            result = cloudinary.uploader.upload(file.file, folder="e-vote-ids")
            doc_url = result['secure_url']
        except:
            pass
    
    user = db.query(models.User).filter(models.User.id == user_id).first()
    user.document_url = doc_url
    db.commit()
    return {"success": True, "url": doc_url}

# ==================== ADMIN DASHBOARD ====================

@app.get("/api/admin/stats")
def admin_stats(db: Session = Depends(get_db)):
    voters = db.query(models.User).filter(models.User.role == "VOTER").all()
    pending_names = {u.username.strip().casefold() for u in voters if u.status == "PENDING"}
    approved_names = {u.username.strip().casefold() for u in voters if u.status == "VERIFIED"}
    party_names = {p.name.strip().casefold() for p in db.query(models.Party).all() if p.name}
    return {
        "total_votes": db.query(models.Vote).count(),
        "pending": len(pending_names),
        "approved": len(approved_names),
        "parties": len(party_names)
    }

@app.get("/api/admin/pending")
def get_pending(db: Session = Depends(get_db)):
    users = db.query(models.User).filter(
        models.User.status == "PENDING",
        models.User.role == "VOTER"
    ).all()
    unique = {}
    for u in users:
        unique.setdefault(u.username.strip().casefold(), {"id": u.id, "username": u.username, "phone": u.phone})
    return list(unique.values())

@app.post("/api/admin/approve/{user_id}")
def approve_user(user_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    user.status = "VERIFIED"
    db.commit()
    return {"success": True}

@app.get("/api/admin/approved-users")
def get_approved_users(db: Session = Depends(get_db)):
    users = db.query(models.User).filter(
        models.User.status == "VERIFIED",
        models.User.role == "VOTER"
    ).all()
    unique = {}
    for u in users:
        unique.setdefault(u.username.strip().casefold(), {
            "id": u.id, "username": u.username, "phone": u.phone,
            "face_enrolled": u.face_enrolled
        })
    return list(unique.values())

# ==================== FACE RECOGNITION ====================

@app.post("/api/admin/enroll-face/{user_id}")
async def enroll_face(user_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    
    user.face_enrolled = True
    db.commit()
    return {"success": True, "message": "Face enrollment initiated"}

@app.post("/api/admin/upload-face-image/{user_id}")
async def upload_face_image(
    user_id: str,
    face_image: str,  # Base64 encoded image
    db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    
    try:
        # Decode base64 image
        image_array = FaceRecognizer.decode_base64_image(face_image)
        
        if image_array is None:
            raise HTTPException(400, "Invalid image data")
        
        # Encode face
        face_encoding = FaceRecognizer.encode_face(image_array=image_array)
        
        if face_encoding is None:
            raise HTTPException(400, "No face detected. Please ensure face is clearly visible.")
        
        # Store face encoding as JSON string
        user.face_encoding = json.dumps(face_encoding)
        user.face_enrolled = True
        
        db.commit()
        return {"success": True, "message": "Face enrolled successfully!"}
        
    except Exception as e:
        raise HTTPException(500, f"Error processing face: {str(e)}")

@app.post("/api/voter/verify-face")
async def verify_face(
    face_image: str,
    user_id: str,
    db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    
    if not user.face_enrolled or not user.face_encoding:
        raise HTTPException(400, "Face not enrolled. Contact admin.")
    
    try:
        image_array = FaceRecognizer.decode_base64_image(face_image)
        if image_array is None:
            raise HTTPException(400, "Invalid image data")
        
        stored_encoding = json.loads(user.face_encoding)
        is_match, confidence = FaceRecognizer.verify_face(stored_encoding, image_array)
        
        if is_match and confidence >= 70:
            return {
                "success": True,
                "message": f"Face verified! Confidence: {confidence:.1f}%",
                "confidence": confidence
            }
        else:
            raise HTTPException(
                401,
                f"Verification failed. Confidence: {confidence:.1f}%. Try again."
            )
    except Exception as e:
        raise HTTPException(500, f"Verification error: {str(e)}")

# ==================== ADMIN MANAGEMENT ====================

@app.get("/api/admin/admins")
def get_admins(db: Session = Depends(get_db)):
    admins = db.query(models.User).filter(models.User.role == "ADMIN").all()
    return [{"id": a.id, "username": a.username, "phone": a.phone} for a in admins]

@app.post("/api/admin/create-admin")
def create_admin(admin: schemas.AdminCreate, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.username == admin.username).first():
        raise HTTPException(400, "Username already exists")
    
    db_admin = models.User(
        id=str(uuid.uuid4()),
        username=admin.username,
        phone=admin.phone,
        password=admin.password,
        role="ADMIN",
        status="VERIFIED"
    )
    db.add(db_admin)
    db.commit()
    return {"success": True}

@app.post("/api/admin/delete-admin/{admin_id}")
def delete_admin(admin_id: str, db: Session = Depends(get_db)):
    admin = db.query(models.User).filter(
        models.User.id == admin_id,
        models.User.role == "ADMIN"
    ).first()
    if not admin:
        raise HTTPException(404, "Admin not found")
    db.delete(admin)
    db.commit()
    return {"success": True}

# ==================== PARTY & CANDIDATES ====================

@app.post("/api/admin/parties")
def create_party(party: schemas.PartyCreate, db: Session = Depends(get_db)):
    db_party = models.Party(
        id=str(uuid.uuid4()),
        **party.dict()
    )
    db.add(db_party)
    db.commit()
    return {"success": True}

@app.get("/api/admin/parties")
def get_parties(db: Session = Depends(get_db)):
    parties = db.query(models.Party).all()
    return [
        {
            "id": p.id,
            "name": p.name,
            "symbol": p.symbol,
            "color": p.color,
            "manifesto": p.manifesto
        }
        for p in parties
    ]

@app.post("/api/admin/candidates")
def add_candidate(cand: schemas.CandidateCreate, db: Session = Depends(get_db)):
    db_cand = models.Candidate(
        id=str(uuid.uuid4()),
        **cand.dict()
    )
    db.add(db_cand)
    db.commit()
    return {"success": True}

# ==================== ELECTION MANAGEMENT ====================

@app.post("/api/admin/elections")
def create_election(elec: schemas.ElectionCreate, db: Session = Depends(get_db)):
    db_elec = models.Election(
        id=str(uuid.uuid4()),
        title=elec.title,
        status="ACTIVE"
    )
    db.add(db_elec)
    db.commit()
    return {"success": True, "id": db_elec.id}

@app.get("/api/admin/elections")
def get_elections(db: Session = Depends(get_db)):
    elecs = db.query(models.Election).all()
    return [
        {"id": e.id, "title": e.title, "status": e.status, "votes": len(e.votes)}
        for e in elecs
    ]

@app.post("/api/admin/release/{election_id}")
def release_results(election_id: str, db: Session = Depends(get_db)):
    elec = db.query(models.Election).filter(models.Election.id == election_id).first()
    elec.status = "RELEASED"
    db.commit()
    return {"success": True}

# ==================== VOTING ====================

@app.get("/api/voter/candidates/{election_id}")
def get_candidates(election_id: str, db: Session = Depends(get_db)):
    cands = db.query(models.Candidate).all()
    unique = {}
    for c in cands:
        key = (c.name.strip().casefold(), (c.position or "").strip().casefold(), c.party_id)
        unique.setdefault(key, {"id": c.id, "name": c.name, "party": c.party.name, "color": c.party.color})
    return list(unique.values())

@app.post("/api/voter/vote")
def cast_vote(vote: schemas.VoteRequest, db: Session = Depends(get_db)):
    if db.query(models.Vote).filter(models.Vote.user_id == vote.user_id).first():
        raise HTTPException(409, "Already voted")
    
    # Generate blockchain hash
    raw = f"{vote.user_id}-{vote.candidate_id}-{os.urandom(16).hex()}"
    block_hash = hashlib.sha256(raw.encode()).hexdigest()
    
    db_vote = models.Vote(
        id=str(uuid.uuid4()),
        user_id=vote.user_id,
        candidate_id=vote.candidate_id,
        election_id=vote.election_id,
        block_hash=block_hash
    )
    db.add(db_vote)
    db.commit()
    return {"success": True, "receipt": block_hash}

# ==================== RESULTS ====================

@app.get("/api/results/{election_id}")
def get_results(election_id: str, db: Session = Depends(get_db)):
    cands = db.query(models.Candidate).all()
    grouped = {}
    for c in cands:
        key = (c.name.strip().casefold(), (c.position or "").strip().casefold(), c.party_id)
        row = grouped.setdefault(key, {"name": c.name, "party": c.party.name, "color": c.party.color, "votes": 0})
        row["votes"] += db.query(models.Vote).filter(
            models.Vote.candidate_id == c.id,
            models.Vote.election_id == election_id
        ).count()
    return list(grouped.values())

# ==================== SERVE FRONTEND ====================

app.mount("/", StaticFiles(directory="static", html=True), name="static")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)


