from sqlalchemy import Column, String, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(String, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    email = Column(String, unique=True, index=True, nullable=True)
    phone = Column(String)
    password = Column(String, nullable=False)
    role = Column(String, default="VOTER")  # VOTER, ADMIN, SUPER_ADMIN
    status = Column(String, default="PENDING")  # PENDING, VERIFIED, REJECTED
    document_url = Column(String, nullable=True)
    face_encoding = Column(Text, nullable=True)  # JSON string of face encoding
    face_enrolled = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    votes = relationship("Vote", back_populates="user", cascade="all, delete-orphan")


class Party(Base):
    __tablename__ = "parties"
    
    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    symbol = Column(String)
    color = Column(String, default="#0066ff")
    manifesto = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    candidates = relationship("Candidate", back_populates="party", cascade="all, delete-orphan")


class Candidate(Base):
    __tablename__ = "candidates"
    
    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    position = Column(String)
    party_id = Column(String, ForeignKey("parties.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    party = relationship("Party", back_populates="candidates")
    votes = relationship("Vote", back_populates="candidate", cascade="all, delete-orphan")


class Election(Base):
    __tablename__ = "elections"
    
    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    status = Column(String, default="PENDING")  # PENDING, ACTIVE, RELEASED
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    votes = relationship("Vote", back_populates="election", cascade="all, delete-orphan")


class Vote(Base):
    __tablename__ = "votes"
    
    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)
    election_id = Column(String, ForeignKey("elections.id"), nullable=False)
    block_hash = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="votes")
    candidate = relationship("Candidate", back_populates="votes")
    election = relationship("Election", back_populates="votes")


