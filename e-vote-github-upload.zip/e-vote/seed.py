from database import SessionLocal, create_tables
import models
import uuid

def seed_database():
    # Create tables first
    create_tables()
    
    db = SessionLocal()
    
    try:
        # Create Super Admin
        if not db.query(models.User).filter(models.User.username.ilike("superadmin")).first():
            super_admin = models.User(
                id=str(uuid.uuid4()),
                username="superadmin",
                email="superadmin@evote.com",
                phone="0000000000",
                password="super123",
                role="SUPER_ADMIN",
                status="VERIFIED",
                face_enrolled=True
            )
            db.add(super_admin)
            print("✅ Super Admin created - Username: superadmin, Password: super123")
        
        # Create Normal Admin
        if not db.query(models.User).filter(models.User.username.ilike("admin")).first():
            admin = models.User(
                id=str(uuid.uuid4()),
                username="admin",
                email="admin@evote.com",
                phone="1111111111",
                password="admin123",
                role="ADMIN",
                status="VERIFIED",
                face_enrolled=True
            )
            db.add(admin)
            print("✅ Admin created - Username: admin, Password: admin123")
        
        # Create Test Voter
        if not db.query(models.User).filter(models.User.username.ilike("voter1")).first():
            voter = models.User(
                id=str(uuid.uuid4()),
                username="voter1",
                email="voter1@test.com",
                phone="2222222222",
                password="voter123",
                role="VOTER",
                status="VERIFIED",
                face_enrolled=True
            )
            db.add(voter)
            print("✅ Voter created - Username: voter1, Password: voter123")
        
        # Create the demo party and candidate only when absent.
        party = db.query(models.Party).filter(
            models.Party.name.ilike("Digital Progressives")
        ).first()
        if not party:
            party = models.Party(
                id=str(uuid.uuid4()), name="Digital Progressives", symbol="🚀",
                color="#0066ff", manifesto="Innovation for all"
            )
            db.add(party)
            db.flush()

        candidate_exists = db.query(models.Candidate).filter(
            models.Candidate.name.ilike("Alice Tech"),
            models.Candidate.position.ilike("President"),
            models.Candidate.party_id == party.id
        ).first()
        if not candidate_exists:
            db.add(models.Candidate(
                id=str(uuid.uuid4()), name="Alice Tech", position="President", party_id=party.id
            ))
            print("✅ Demo candidate created")
        
        # Create Election
        if not db.query(models.Election).first():
            election = models.Election(
                id=str(uuid.uuid4()),
                title="Digital Election 2026",
                status="ACTIVE"
            )
            db.add(election)
            print("✅ Election created")
        
        db.commit()
        print("\n🎉 Database seeded successfully!")
        print("\n📋 Default Credentials:")
        print("   - Super Admin: superadmin / super123")
        print("   - Admin: admin / admin123")
        print("   - Voter: voter1 / voter123")
        
    except Exception as e:
        db.rollback()
        print(f"❌ Error seeding database: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()

