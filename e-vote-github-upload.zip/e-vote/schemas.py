from pydantic import BaseModel, Field
from typing import Optional

class UserRegister(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    phone: str = Field(min_length=7, max_length=24)
    password: str = Field(min_length=8, max_length=128)

class LoginRequest(BaseModel):
    username: str
    password: str

class AdminCreate(BaseModel):
    username: str
    phone: str
    password: str

class PartyCreate(BaseModel):
    name: str
    symbol: Optional[str] = None
    color: str = "#3478f6"
    manifesto: Optional[str] = None

class CandidateCreate(BaseModel):
    name: str
    position: str
    party_id: str

class ElectionCreate(BaseModel):
    title: str

class VoteRequest(BaseModel):
    user_id: str
    candidate_id: str
    election_id: str
