from database import SessionLocal, create_tables
import models
import uuid

def seed_database():
    # Create tables first
    create_tables()
    
    db = SessionLocal()
    
    try:
        # No local test accounts are created. Administrator bootstrap must be
        # implemented securely before this API is used.

        # Create the demo party and candidate only when absent.
        party = db.query(models.Party).filter(
            models.Party.name.ilike("Digital Progressives")
        ).first()
        if not party:
            party = models.Party(
                id=str(uuid.uuid4()), name="Digital Progressives", symbol="🚀",
                color="#0066ff", manifesto="Innovation for all"
            )
            db.add(party)
            db.flush()

        candidate_exists = db.query(models.Candidate).filter(
            models.Candidate.name.ilike("Alice Tech"),
            models.Candidate.position.ilike("President"),
            models.Candidate.party_id == party.id
        ).first()
        if not candidate_exists:
            db.add(models.Candidate(
                id=str(uuid.uuid4()), name="Alice Tech", position="President", party_id=party.id
            ))
            print("✅ Demo candidate created")
        
        # Create Election
        if not db.query(models.Election).first():
            election = models.Election(
                id=str(uuid.uuid4()),
                title="Digital Election 2026",
                status="ACTIVE"
            )
            db.add(election)
            print("✅ Election created")
        
        db.commit()
        print("\n🎉 Database seeded successfully!")
        
    except Exception as e:
        db.rollback()
        print(f"❌ Error seeding database: {e}")
        raise
    finally:
        db.close()

if __name__ == "__main__":
    seed_database()

